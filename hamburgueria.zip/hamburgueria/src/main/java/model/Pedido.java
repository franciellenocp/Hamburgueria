package model;

public class Pedido {
    //Atributos
    private Produto produto;
    private String nome_cliente;
    private int quantidade;
    private String obsPedido;
    private boolean entregue;
    private String statusPagamento;
    private double valor_total;
    private double troco;

    //Construtor
    public Pedido(Produto produto, String nome_cliente, int quantidade) {
        this.produto = produto;
        this.nome_cliente = nome_cliente;
        this.quantidade = quantidade;
        this.obsPedido = "AGUARDANDO_PAGAMENTO";
        this.statusPagamento = "AGUARDANDO";
        this.entregue=false;
        this.valor_total = 0;
        this.troco = 0;
    }

    //Métodos

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public String getNome_cliente() {
        return nome_cliente;
    }

    public void setNome_cliente(String nome_cliente) {
        this.nome_cliente = nome_cliente;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getObsPedido() {
        return obsPedido;
    }

    public void setObsPedido(String obsPedido) {
        this.obsPedido = obsPedido;
    }

    public String getStatusPagamento() {
        return statusPagamento;
    }

    public void setStatusPagamento(String statusPagamento) {
        this.statusPagamento = statusPagamento;
    }

    public boolean isEntregue() {
        return entregue;
    }

    public void setEntregue(boolean entregue) {
        this.entregue = entregue;
    }

    public double getValor_total() {
        return valor_total;
    }

    public void setValor_total(double valor_total) {
        this.valor_total = valor_total;
    }

    public double getTroco() {
        return troco;
    }

    public void setTroco(double troco) {
        this.troco = troco;
    }

    @Override
    public String toString() {
        return "Pedido{" +
                "produto=" + produto +
                ", nome_cliente='" + nome_cliente + '\'' +
                ", quantidade=" + quantidade +
                ", obsPedido='" + obsPedido + '\'' +
                ", entregue=" + entregue +
                ", statusPagamento='" + statusPagamento + '\'' +
                ", valor_total=" + valor_total +
                ", troco=" + troco +
                '}';
    }
}
