package model;

public class Produto {
    //Atributos
    private String nome_produto;
    private double valor_produto;

    //Construtor

    public Produto(String nome_produto, double valor_produto) {
        this.nome_produto = nome_produto;
        this.valor_produto = valor_produto;
    }

    //Metódo

    public String getNome_produto() {
        return nome_produto;
    }

    public void setNome_produto(String nome_produto) {
        this.nome_produto = nome_produto;
    }

    public double getValor_produto() {
        return valor_produto;
    }

    public void setValor_produto(double valor_produto) {
        this.valor_produto = valor_produto;
    }

    @Override
    public String toString() {
        return "Produto{" +
                "nome_produto='" + nome_produto + '\'' +
                ", valor_produto=" + valor_produto +
                '}';
    }
}
