public class Main {
    /**Enunciado
     Cada aluno deverá criar seu próprio programa Java e realizar todos os testes.
     *Os requisitos mínimos são: *
     0 - Utilizar Junit 5 para todos os testes
     1 - Criar 2 classes service
     2 - Criar 1 entidade
     3 - Criar 6 métodos
     4 - Possuir 90% de coverage
     5 - Criar 1 teste de exception
     6 - Utilizar mocks
     7 - Adicionar o Jacoco ao projeto
     */

/**Hamburgueria da Fran
 *Projeto Hamburgueria da Fran
 * Bem vindo a Hamburgueria da Fran!!
 * Informações:
 * Para realizar um Pedido é necessário informar:
 * - Seu nome (Cliente)
 * - Produto contendo 'Nome e valor'
 * - Quantidade
 *
 * Não é possivel realizar um pedido com quantidade menor ou igual a Zero.
 * Não é possível realizar um pedido com valor menor ou igual a Zero.
 *
 * Todo pedido para ser confirmado, deve ser pago!
 *
 * Quer desistir do Pedido? Que pena..
 * Mas, temos as seguintes opções:
 * - Cancelar após Pago e Não Entregue
 * - Cancelar após Pago e Entregue
 *
 * Importante lembrar que:
 * - Não deve ser possivel cancelar um pedido sem ter pago
 * - Não deve ser possivel receber um pedido sem ter pago
 *
 * - Só é possível devolver um pagamento, após cancelar o produto.
 *
 * Para Produtos:
 * Não é possível cadastrar produtos com valor igual ou menor que Zero.
 * Não é possível cadastrar produtos com nome nulo
 *
 * De 3 em 3 meses temos o reajuste nos preços:
 * Se produto tiver preço superior a 100 reais -> aplicar 10%
 * Se produto for de 50 reais até 100->  aplicar 7%
 * Se produto for ate 50reais -> aplicar 3%
 *
 */
/**Considerações:
  2 Classes:
 Produto
 Pedido

 2 Classes Services
 2 Classes Test

 De acordo com o Enunciado:
 Cada aluno deverá criar seu próprio programa Java  - OK
 0 - Utilizar Junit 5 para todos os testes - OK
 1 - Criar 2 classes service - OK
 Pensei em separa Pagamento em uma classe service,
 mas não consegui acessar os valores do pedido pela classe Pagamento
 Ai usei a classe Produto pra inclusões mais simples
 2 - Criar 1 entidade - OK
 3 - Criar 6 métodos - OK
 4 - Possuir 90% de coverage - Pedido OK
 5 - Criar 1 teste de exception - OK
 6 - Utilizar mocks - NOK
 Pensei em utilizar os mocks para mockar os pagamentos no
 método cancelar 'PedidoServicetest', mas não consegui criar.
 Pensei em usar no metodo de alterar valor do produto, mockando uma data, mas, não consegui tbm
 7 - Adicionar o Jacoco ao projeto - NOK
 Tentei de várias formas, e percebi que minha variável de ambiente do Java não estava configurada, tentei fazer, mas como uso o pc da empresa fiquei com receio de ter algum problema alterando as variaveis de ambiente.
 Vou tentar reinistalar a jdk e o intellij, mas, não consegui fazer a tempo da entrega.
 */

}
