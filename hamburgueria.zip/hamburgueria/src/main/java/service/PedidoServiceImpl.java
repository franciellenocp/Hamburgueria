package service;

import model.Pedido;

public class PedidoServiceImpl implements PedidoService {

    @Override
    public void fazerPedido(Pedido pedido) throws Exception {
        if ((pedido.getProduto().getValor_produto() <= 0) || (pedido.getQuantidade() <= 0)) {
            pedido.setObsPedido("PEDIDO_CANCELADO");
            pedido.setStatusPagamento("CANCELADO");
            throw new Exception("Valor e quantidade devem ser maiores que zero");
        } else {
            pedido.setObsPedido("PEDIDO_AGUARDANDO_PAGAMENTO");
        }
    }

    @Override
    public void cancelar(Pedido pedido, boolean recebido) throws Exception {
        if (pedido.getObsPedido().equals("PEDIDO_ENTREGUE")) {
            if (pedido.getStatusPagamento().equals("PAGO")) {
                pedido.setObsPedido("PEDIDO_DEVOLVIDO");
            }
        } else if (pedido.getObsPedido().equals("PEDIDO_CONFIRMADO")) {
            if (pedido.getStatusPagamento().equals("PAGO")) {
                pedido.setObsPedido("PEDIDO_CANCELADO");
            }
        } else if (!pedido.getStatusPagamento().equals("PAGO")) {
            pedido.setObsPedido("PEDIDO_CANCELADO");
            pedido.setStatusPagamento("CANCELADO");
            throw new Exception("Pedido só é confirmado após ser pago!");
        }

    }

    @Override
    public void receberPedido(Pedido pedido) throws Exception {
        if (pedido.getStatusPagamento().equals("PAGO")) {
            pedido.setObsPedido("PEDIDO_CONFIRMADO");

        } else {
            pedido.setObsPedido("PEDIDO_CANCELADO");
            pedido.setStatusPagamento("CANCELADO");
            throw new Exception("Só seguiremos após Pagamento do pedido!");
        }

    }

    @Override
    public void pagar(Pedido pedido, double valor) throws Exception {
        pedido.setValor_total(pedido.getProduto().getValor_produto() * pedido.getQuantidade());
        if (pedido.getValor_total() == valor) {
            pedido.setStatusPagamento("PAGO");
            pedido.setObsPedido("PEDIDO_CONFIRMADO");
        } else if (pedido.getValor_total() < valor) {
            pedido.setTroco(valor - pedido.getValor_total());
            pedido.setStatusPagamento("PAGO");
            pedido.setObsPedido("PEDIDO_CONFIRMADO");
        } else {
            pedido.setStatusPagamento("INVALIDO");
            pedido.setObsPedido("PEDIDO_CANCELADO");
            throw new Exception("Valor pago inferior ao pedido");
        }
    }

    @Override
    public void devolverPagamento(Pedido pedido, double valor) throws Exception {
        if (pedido.getValor_total() == valor) {
            pedido.setStatusPagamento("DEVOLVIDO");
            pedido.setValor_total(0);
        } else if ((pedido.getValor_total() > valor)
                || (pedido.getValor_total() < valor)) {
            pedido.setStatusPagamento("INVÁLIDO");
            throw new Exception("Valor a ser devolvido está maior ou menor que o pago");
        }
    }

    @Override
    public void alterarStatusPedido(Pedido pedido, boolean entregue) {
        if (pedido.getStatusPagamento().equals("PAGO")) {
            if (pedido.getObsPedido().equals("PEDIDO_CONFIRMADO")) {
                pedido.setEntregue(true);
                pedido.setObsPedido("PEDIDO_ENTREGUE");
            } else if(!pedido.getObsPedido().equals("PEDIDO_CONFIRMADO")){
                pedido.setEntregue(false);
                pedido.setObsPedido("PEDIDO_CANCELADO");
            }
        }
    }

    @Override
    public String estadoAtual(Pedido pedido) {
        return pedido.toString();
    }
}
