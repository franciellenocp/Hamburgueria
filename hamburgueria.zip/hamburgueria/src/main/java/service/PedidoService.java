package service;

import model.Pedido;

public interface PedidoService {
    void fazerPedido(Pedido pedido) throws Exception;
    void cancelar(Pedido pedido, boolean recebido) throws Exception;
    void receberPedido(Pedido pedido)throws Exception;

    void pagar(Pedido pedido, double valor) throws Exception;
    void devolverPagamento(Pedido pedido, double valor) throws Exception;

    void  alterarStatusPedido(Pedido pedido, boolean entregue);

    String estadoAtual(Pedido pedido);

}
