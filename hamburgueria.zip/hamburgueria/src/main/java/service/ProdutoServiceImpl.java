package service;

import model.Pedido;
import model.Produto;

import java.util.ArrayList;

public class ProdutoServiceImpl implements ProdutoService {
    @Override
    public void cadastrar(String nome_produto, double valor_produto) throws Exception {
        ArrayList<Produto> arrayProduto = new ArrayList<Produto>();
        if (nome_produto == null) {
            throw new Exception("Nome Inválido");
        } else if (valor_produto <= 0) {
            throw new Exception("Valor Inválido");
        } else {
            Produto produto = new Produto(nome_produto, valor_produto);
            arrayProduto.add(produto);
            System.out.println(produto.toString());
        }
    }

    @Override
    public void editarValorProduto(Produto produto) {
        if (produto.getValor_produto() <= 50.00) {
            produto.setValor_produto(produto.getValor_produto() * 1.03);
        } else if ((produto.getValor_produto() > 50.00) && (produto.getValor_produto() <= 100.00)) {
            produto.setValor_produto(produto.getValor_produto() * 1.07);
        } else if (produto.getValor_produto() > 100.00) {
            produto.setValor_produto(produto.getValor_produto() * 1.10);
        }
    }

    @Override
    public String estadoAtualProduto(Produto produto) {
        return produto.toString();
    }
}
