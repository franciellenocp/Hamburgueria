package service;

import model.Pedido;
import model.Produto;

import java.util.ArrayList;

public interface ProdutoService {

    void cadastrar(String nome_produto, double valor_produto) throws Exception;
    void editarValorProduto(Produto Produto);
    String estadoAtualProduto(Produto produto);
}
