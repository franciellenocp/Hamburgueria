package service;

import model.Pedido;
import model.Produto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PedidoServiceTest {
    PedidoService pedidoService;

    @BeforeEach
    public void setup() {
        pedidoService = new PedidoServiceImpl();
    }

    @Test
    @DisplayName("CT001 - Validar Fazer Pedido")
    public void realizarPedido() throws Exception {
        //Given
        Produto produto = new Produto("X-Salada", 40.50);
        Pedido pedido = new Pedido(produto, "Joao", 1);
        System.out.println("Estado Inicial: " + pedidoService.estadoAtual(pedido));
        //When
        pedidoService.fazerPedido(pedido);
         //Then
        assertEquals("PEDIDO_AGUARDANDO_PAGAMENTO", pedido.getObsPedido());
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
    }

    @Test
    @DisplayName("CT002 - Validar Fazer Pedido valor 0 - Exception")
    public void realizarPedidoProdutoZero() throws Exception {
        //Given
        Produto produto = new Produto("X-Salada", 0);
        Pedido pedido = new Pedido(produto, "Joao", 1);
        System.out.println("Estado Inicial: " + pedidoService.estadoAtual(pedido));
        //When
        Throwable throwable = assertThrows(Exception.class,
                () -> pedidoService.fazerPedido(pedido)
        );
        //Then
        assertEquals("Valor e quantidade devem ser maiores que zero", throwable.getMessage());
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
    }

    @Test
    @DisplayName("CT003 - Validar Fazer Pedido valor menor que 0 - Exception")
    public void realizarPedidoProdutoMenorQueZero() throws Exception {
        //Given
        Produto produto = new Produto("X-Salada", -10.90);
        Pedido pedido = new Pedido(produto, "Joao", 1);
        System.out.println("Estado Inicial: " + pedidoService.estadoAtual(pedido));
        //When
        Throwable throwable = assertThrows(Exception.class,
                () -> pedidoService.fazerPedido(pedido)
        );
        //Then
        assertEquals("Valor e quantidade devem ser maiores que zero", throwable.getMessage());
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
    }

    @Test
    @DisplayName("CT004 - Validar Fazer Pedido com valor sem quantidade - Exception")
    public void realizarPedidoQuantidadeZero() throws Exception {
        //Given
        Produto produto = new Produto("Combo X-Salada", 50.90);
        Pedido pedido = new Pedido(produto, "Maria", 0);
        System.out.println("Estado Inicial: " + pedidoService.estadoAtual(pedido));
        //When
        Throwable throwable = assertThrows(Exception.class,
                () -> pedidoService.fazerPedido(pedido)
        );
        //Then
        assertEquals("Valor e quantidade devem ser maiores que zero", throwable.getMessage());
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
    }

    @Test
    @DisplayName("CT005 - Validar Cancelar Pedido Após Receber Produto")
    public void cancelarPedidoProdutoRecebido() throws Exception {
        //Given
        Produto produto = new Produto("X-Salada", 40.50);
        Pedido pedido = new Pedido(produto, "Joao", 1);
        pedidoService.fazerPedido(pedido);
        pedidoService.pagar(pedido, 40.50);
        pedidoService.alterarStatusPedido(pedido,true);
        System.out.println("Estado Inicial: " + pedidoService.estadoAtual(pedido));
        //When
        pedidoService.cancelar(pedido, true);
        //Then
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
        assertEquals("PEDIDO_DEVOLVIDO", pedido.getObsPedido());
    }

    @Test
    @DisplayName("CT006 - Validar Cancelar Pedido Sem ter Recebido")
    public void cancelarPedidoNaoRecebido() throws Exception {
        //Given
        Produto produto = new Produto("X-Salada", 40.50);
        Pedido pedido = new Pedido(produto, "Joao", 1);
        pedidoService.fazerPedido(pedido);
        pedidoService.pagar(pedido,40.50);
        System.out.println("Estado Inicial: " + pedidoService.estadoAtual(pedido));
        //When
        pedidoService.cancelar(pedido, false);
        //Then
        assertEquals("PEDIDO_CANCELADO", pedido.getObsPedido());
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
    }

    @Test
    @DisplayName("CT007 - Validar Cancelar Pedido Sem ter Pago")
    public void cancelarPedidoSemTerPago() throws Exception {
        //Given
        Produto produto = new Produto("X-Salada", 40.50);
        Pedido pedido = new Pedido(produto, "Joao", 1);
        pedidoService.fazerPedido(pedido);
        System.out.println("Estado Inicial: " + pedidoService.estadoAtual(pedido));
        //When
          Throwable throwable = assertThrows(Exception.class,
                () -> pedidoService.cancelar(pedido, false)
        );
        //Then
        assertEquals("Pedido só é confirmado após ser pago!", throwable.getMessage());
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
    }

    @Test
    @DisplayName("CT008 - Validar Produto Pago e Recebido")
    public void validarProdutoRecebidoEPago() throws Exception {
        //Given
        Produto produto = new Produto("X-Salada", 40.50);
        Pedido pedido = new Pedido(produto, "Joao", 1);
        System.out.println("Estado Inicial: " + pedidoService.estadoAtual(pedido));
        pedidoService.fazerPedido(pedido);
        pedidoService.pagar(pedido, 40.50);

        //When
        pedidoService.receberPedido(pedido);
        //Then
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
        assertEquals("PEDIDO_CONFIRMADO", pedido.getObsPedido());
    }

    @Test
    @DisplayName("CT009 - Validar Produto Sem Pagamento")
    public void validarProdutoSemPagamento() throws Exception {
        //Given
        Produto produto = new Produto("X-Salada", 40.50);
        Pedido pedido = new Pedido(produto, "Joao", 1);
        System.out.println("Estado Inicial: " + pedidoService.estadoAtual(pedido));
        pedidoService.fazerPedido(pedido);
        //When

        Throwable throwable = assertThrows(Exception.class,
                () ->pedidoService.receberPedido(pedido)
        );
        //Then
        assertEquals("Só seguiremos após Pagamento do pedido!", throwable.getMessage());
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));

    }

    @Test
    @DisplayName("CT010 - Validar Pagamento do Pedido")
    public void realizarPagamentoPedido() throws Exception {
        //Given
        Produto produto = new Produto("Combo X-Salada", 50.90);
        Pedido pedido = new Pedido(produto, "Mariana", 4);
        System.out.println("Estado Inicial: " + pedidoService.estadoAtual(pedido));
        pedidoService.fazerPedido(pedido);
        //When
        pedidoService.pagar(pedido, 203.60);
        //Then
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
        assertEquals(203.60, pedido.getValor_total());
    }

    @Test
    @DisplayName("CT011 - Validar Pagamento  Valor SUPERIOR ao Pedido")
    public void realizarPagamentoSuperiorPedido() throws Exception {
        //Given
        Produto produto = new Produto("Combo X-Salada", 10.00);
        Pedido pedido = new Pedido(produto, "Mariana", 4);
        System.out.println("Estado Inicial: " + pedidoService.estadoAtual(pedido));
        pedidoService.fazerPedido(pedido);
        //When
        pedidoService.pagar(pedido, 100.00);
        //Then
        assertEquals(40.00, pedido.getValor_total(), 0.00);
        assertEquals(60.00, pedido.getTroco(), 0.00);
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
    }

    @Test
    @DisplayName("CT012 - Validar Pagamento  Valor INFERIOR ao Pedido")
    public void realizarPagamentoInferiorPedido() throws Exception {
        //Given
        Produto produto = new Produto("Combo X-Salada", 10.00);
        Pedido pedido = new Pedido(produto, "Mariana", 4);
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
        pedidoService.fazerPedido(pedido);

        //When
        Throwable throwable = assertThrows(Exception.class,
                () -> pedidoService.pagar(pedido, 10.60)
        );
        //Then
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
        assertEquals("Valor pago inferior ao pedido", throwable.getMessage());
    }

    @Test
    @DisplayName("CT013 - Validar Devolução do Pagamento")
    public void realizarDevolucaoDoPagamento() throws Exception {
        //Given
        Produto produto = new Produto("Combo X-Salada", 10.00);
        Pedido pedido = new Pedido(produto, "Mariana", 4);
        pedidoService.fazerPedido(pedido);
        pedidoService.pagar(pedido, 40);
        System.out.println("Estado Inicial: " + pedidoService.estadoAtual(pedido));
        //When
        pedidoService.cancelar(pedido, true);
        pedidoService.devolverPagamento(pedido, pedido.getValor_total());
        //Then
        assertEquals(0, pedido.getValor_total());
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
    }

    @Test
    @DisplayName("CT014 - Validar Devolução do Pagamento Menor que o Pago")
    public void realizarDevolucaoDoPagamentoMenor() throws Exception {
        //Given
        Produto produto = new Produto("Combo X-Salada", 10.00);
        Pedido pedido = new Pedido(produto, "Mariana", 4);
        pedidoService.fazerPedido(pedido);
        pedidoService.pagar(pedido, 40);
        System.out.println("Estado Inicial: " + pedidoService.estadoAtual(pedido));
        //When
        pedidoService.cancelar(pedido, true);
        Throwable throwable = assertThrows(Exception.class,
                () -> pedidoService.devolverPagamento(pedido, 10)
        );
        //Then
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
        assertEquals("Valor a ser devolvido está maior ou menor que o pago", throwable.getMessage());
    }


    @Test
    @DisplayName("CT015 - Validar Devolução do Pagamento Maior que o Pago")
    public void realizarDevolucaoDoPagamentoMaior() throws Exception {
        //Given
        Produto produto = new Produto("Combo X-Salada", 10.00);
        Pedido pedido = new Pedido(produto, "Mariana", 4);
        System.out.println("Estado Inicial: " + pedidoService.estadoAtual(pedido));
        pedidoService.fazerPedido(pedido);
        pedidoService.pagar(pedido, 40);
        pedidoService.cancelar(pedido, true);

        //When
        Throwable throwable = assertThrows(Exception.class,
                () -> pedidoService.devolverPagamento(pedido, 200.00)
        );
        //Then
        System.out.println("Estado Final: " + pedidoService.estadoAtual(pedido));
        assertEquals("Valor a ser devolvido está maior ou menor que o pago", throwable.getMessage());

    }
}
