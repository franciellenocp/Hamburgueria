package service;

import model.Produto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import static org.junit.jupiter.api.Assertions.*;

public class ProdutoServiceTest {
    ProdutoService produtoService;
    @BeforeEach
    public void setup() {
        produtoService = new ProdutoServiceImpl();
    }

    @Test
    @DisplayName("CT001 - Validar inserção de novos Produtos")
    public void cadastrarProdutos() throws Exception {
        //Given
        produtoService.cadastrar("X-Salada", 45.00);
        //Then
       produtoService.toString();
    }
    @Test
    @DisplayName("CT002 - Validar inserção com Nome nulo")
    public void cadastrarProdutosNomeNull() throws Exception {
        //Given
        Throwable throwable = assertThrows(Exception.class,
                () -> produtoService.cadastrar(null, 45.00)
        );
        //Then
        assertEquals("Nome Inválido", throwable.getMessage());
    }
    @Test
    @DisplayName("CT003 - Validar inserção com Valor menor que Zero")
    public void cadastrarProdutosValorMenorQueZero() throws Exception {
        //Given
        Throwable throwable = assertThrows(Exception.class,
                () -> produtoService.cadastrar("X-salada", -45.00)
        );
        //Then
        assertEquals("Valor Inválido", throwable.getMessage());
    }
    @Test
    @DisplayName("CT004 - Validar inserção com Valor igual a Zero")
    public void cadastrarProdutosValorIgualAZero() throws Exception {
        //Given
        Throwable throwable = assertThrows(Exception.class,
                () -> produtoService.cadastrar("X-salada", -45.00)
        );
        //Then
        assertEquals("Valor Inválido", throwable.getMessage());
    }
    @Test
    @DisplayName("CT005 - Validar alteração no Valor produto ate 50.00")
    public void alterarValorProdutosAteCinquenta() throws Exception {
        //Given
        Produto produto = new Produto ("X-Salada", 50.00);
        System.out.println("Estado inicial:" + produtoService.estadoAtualProduto(produto));
        //When
        produtoService.editarValorProduto(produto);
        //Then
        assertEquals(51.5,produto.getValor_produto(),0.00);
        System.out.println("Estado inicial:" + produtoService.estadoAtualProduto(produto));
    }

    @Test
    @DisplayName("CT006 - Validar alteração no Valor produto acima 50 ate 100.00")
    public void alterarValorProdutosAcimaCinquentaAteCem() throws Exception {
        //Given
        Produto produto = new Produto ("X-Salada", 51.00);
        System.out.println("Estado inicial:" + produtoService.estadoAtualProduto(produto));
        //When
        produtoService.editarValorProduto(produto);
        //Then
        assertNotEquals(51.0,produto.getValor_produto(),0.00);
        System.out.println("Estado inicial:" + produtoService.estadoAtualProduto(produto));
    }
    @Test
    @DisplayName("CT007 - Validar alteração no Valor produto acima de 100.00")
    public void alterarValorProdutosAcimaDeCem() throws Exception {
        //Given
        Produto produto = new Produto ("X-Salada", 150.00);
        System.out.println("Estado inicial:" + produtoService.estadoAtualProduto(produto));
        //When
        produtoService.editarValorProduto(produto);
        //Then
        assertNotEquals(103.00,produto.getValor_produto(),0.00);
        System.out.println("Estado inicial:" + produtoService.estadoAtualProduto(produto));
    }
}
